# ------------------------------------------------------------------------------
# Published in:     StatL_class_WS2021
# ------------------------------------------------------------------------------
# Project title:    Facebook post of a cosmetics brand
# ------------------------------------------------------------------------------
# Description:      The code does the following tasks:
#                   - Loading data
#                   - install and load the neuralnet package
#                   - train the neural network with the neuralnet function with three hidden neurons in each layer
#                   - Comparing hidden layer
#                   - Neuronal Network with nnet 
#                   - Result 1 
#                   - Result 2
#                   - Result 3
#          
# ------------------------------------------------------------------------------
# Output:           - Plot of Neural network with 5 neurons 
#                   - Plot of Neural networks with 3 neurons and distinct color
#                   - Plot of Test dataset and prediction
#
# ------------------------------------------------------------------------------
# Author :          Thi Thu Trang Nguyen (s0569071)
# ------------------------------------------------------------------------------
# Dataset:          "dataset_Facebook.csv"
# ------------------------------------------------------------------------------

## Neuronales Netz 
rm(list = ls())
# Building a Neural network with R
# Loading data
dataset <- read.csv2("dataset_Facebook.csv")
dataset <- na.omit(dataset)
ausreisser <- boxplot(dataset$Total.Interactions)$out
dataset <- dataset[-which(dataset$Total.Interactions %in% ausreisser),]

colnames(dataset) <- c("ptl", "type", "cat", "pm", "pd", "ph", "paid", "lptr", 
                       "lpti", "leu", "lpconsumers", "lpconsumption", "lpiliked", 
                       "lprliked", "lpleng", "comments", "likes", "shares", "ti") #Name umbenennen
library(psych)
Dtype <- dummy.code(dataset$type)
dataset <- cbind(dataset, Dtype)
dataset <- dataset[,-2]
dataset <- na.omit(dataset)
fix(dataset)
set.seed(100)
ind <- sample(2, nrow(dataset), replace = TRUE, prob=c(0.7, 0.3))
trainset = dataset[ind == 1,]
testset = dataset[ind == 2,]
trainset #show trainset
testset #show testset
# install and load the neuralnet package:
# install.packages("neuralnet")
library(neuralnet)
## train the neural network with the neuralnet function with three hidden neurons in each layer.
#as.numeric(dataset[dataset$Type])
network = neuralnet(ti ~ Link + Status + Video + ptl + cat + pm + pd + ph + paid + lptr
                    + lpti + leu + lpconsumers + lpconsumption
                    + lpiliked + lprliked
                    + lpleng 
                    , trainset, hidden=3)
network #show detail of the network
network$result.matrix
plot(network)
summary(network)

## Comparing hidden layer

network = neuralnet(ti ~ . - likes - comments - shares
                    ,trainset, act.fct = 'tanh', hidden=5, linear.output = T, learningrate=0.001) 
 
network #show detail of the network
network$result.matrix
plot(network)
summary(network)

pred=predict(network,testset,type='response')
# pred <- Predict$net.result
# pred <- predict(network, testset)
testti <- testset$ti
mean((pred - testti)^2) 


# install.packages('dplyr')
library(dplyr)
vergleich <- data.frame(cbind(testti, pred))
vergleich <- arrange(vergleich, testti)
vergleich$index <- c(1:136)
plot(vergleich$index,vergleich$testti, col = 'green', xlab = 'Index', ylab = 'Total Interactions')
points(vergleich$index,vergleich$pred, col = 'red' )
legend(1,400, legend = c("Testdatensatz", "Vorhersage"), col = c('green','red'), lty = 1)

## Neuronal Network with nnet 
# install.packages("nnet")
# install.packages("NeuralNetTools")
Dtype <- dummy.code(dataset$type)
dataset <- cbind(dataset, Dtype)
dataset <- dataset[,-2]
dataset <- na.omit(dataset)
library(nnet)
library(NeuralNetTools)
ti.nnet <- nnet(ti ~ . - likes - shares - comments, data = trainset, 
                size = 3, decay = 0.1) #Number of circles the hot neurons in the hidden layer
pred=predict(network,testset,type='response')
testti <- testset$ti
mean((pred - testti)^2) 
plotnet(ti.nnet)

## Neuronal Network 
rm(list = ls())
# Loading data
dataset <- read.csv2("dataset_Facebook.csv")
dataset <- na.omit(dataset)
ausreisser <- boxplot(dataset$Total.Interactions)$out
dataset <- dataset[-which(dataset$Total.Interactions %in% ausreisser),]

colnames(dataset) <- c("ptl", "type", "cat", "pm", "pd", "ph", "paid", "lptr", 
                       "lpti", "leu", "lpconsumers", "lpconsumption", "lpiliked", 
                       "lprliked", "lpleng", "comments", "likes", "shares", "ti") #Rename


library(psych)
Dtype <- dummy.code(dataset$type)
dataset <- cbind(dataset, Dtype)
dataset <- dataset[,-2]
dataset <- na.omit(dataset)
fix(dataset)
set.seed(100)
ind <- sample(2, nrow(dataset), replace = TRUE, prob=c(0.7, 0.3))
trainset = dataset[ind == 1,]
testset = dataset[ind == 2,]
trainset #show trainset
testset #show testset
library(neuralnet)
# train the neural network with the neuralnet function with three hidden neurons in each layer.
# as.numeric(dataset[dataset$Type])
network = neuralnet(ti ~ Link + Status + Video + ptl + cat + pm + pd + ph + paid + lptr
                    + lpti + leu + lpconsumers + lpconsumption
                    + lpiliked + lprliked
                    + lpleng 
                    , trainset, hidden=3)
network #show detail of the network
network$result.matrix
plot(network)
summary(network)


# 1.RESULT 
network = neuralnet(ti ~ . - likes - comments - shares
                    ,trainset, act.fct = 'tanh', hidden=5, linear.output = T, learningrate=0.001) 
network #show detail of the network
network$result.matrix
plot(network)
summary(network)
pred=predict(network,testset,type='response')
testti <- testset$ti
mean((pred - testti)^2) 


# install.packages('dplyr')
library(dplyr)
vergleich <- data.frame(cbind(testti, pred))
vergleich <- arrange(vergleich, testti)
vergleich$index <- c(1:136)
plot(vergleich$index,vergleich$testti, col = 'green', xlab = 'Index', ylab = 'Total Interactions')
points(vergleich$index,vergleich$pred, col = 'red' )
legend(1,400, legend = c("Testdataset", "Prediction"), col = c('green','red'), lty = 1)

# 2.RESULT 
library(nnet)
library(NeuralNetTools)
ti.nnet <- nnet(ti ~ . - likes - shares - comments, data = trainset, 
                size = 3, decay = 0.1) 

pred=predict(network,testset,type='response')
testti <- testset$ti
mean((pred - testti)^2) 
plotnet(ti.nnet)

# 3.RESULT
set.seed(100)
ti.nnet = nnet(ti ~ . - likes - shares - comments, data = trainset,
               size = 6, act.fct = 'logistic', linout = T, decay = 0.01)
pred=predict(ti.nnet, newdata = testset)
testti <- testset$ti
mean((pred - testti)^2)
